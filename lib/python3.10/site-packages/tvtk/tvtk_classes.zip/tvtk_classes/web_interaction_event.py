# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class WebInteractionEvent(Object):
    r"""
    WebInteractionEvent - 
    
    Superclass: Object
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkWebInteractionEvent, obj, update, **traits)
    
    buttons = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the mouse buttons state.
        """
    )

    def _buttons_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetButtons,
                        self.buttons)

    key_code = traits.String('', enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get the chart code.
        """
    )

    def _key_code_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetKeyCode,
                        self.key_code)

    modifiers = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get modifier state.
        """
    )

    def _modifiers_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetModifiers,
                        self.modifiers)

    repeat_count = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _repeat_count_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRepeatCount,
                        self.repeat_count)

    scroll = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _scroll_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetScroll,
                        self.scroll)

    x = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        Set/Get event position.
        """
    )

    def _x_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetX,
                        self.x)

    y = traits.Float(0.0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _y_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetY,
                        self.y)

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('buttons', 'GetButtons'), ('key_code',
    'GetKeyCode'), ('modifiers', 'GetModifiers'), ('repeat_count',
    'GetRepeatCount'), ('scroll', 'GetScroll'), ('x', 'GetX'), ('y',
    'GetY'), ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'buttons', 'key_code',
    'modifiers', 'object_name', 'repeat_count', 'scroll', 'x', 'y'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(WebInteractionEvent, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit WebInteractionEvent properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['buttons', 'key_code', 'modifiers', 'object_name',
            'repeat_count', 'scroll', 'x', 'y']),
            title='Edit WebInteractionEvent properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit WebInteractionEvent properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

