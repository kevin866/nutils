# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class StructuredExtent(Object):
    r"""
    StructuredExtent - helper class to aid working with structured
     extents.
    
    Superclass: Object
    
    StructuredExtent is an helper class that helps in arithmetic with
     structured extents. It defines a bunch of static methods (most of
    which are
     inlined) to aid in dealing with extents.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkStructuredExtent, obj, update, **traits)
    
    def get_dimensions(self, *args):
        """
        get_dimensions(ext:(int, int, int, int, int, int), dims:[int, int,
            int]) -> None
        C++: static void get_dimensions(const int ext[6], int dims[3])
        Given the extents, computes the dimensions.
        """
        ret = self._wrap_call(self._vtk_obj.GetDimensions, *args)
        return ret

    def clamp(self, *args):
        """
        clamp(ext:[int, int, int, int, int, int], wholeExt:(int, ...))
            -> None
        C++: static void clamp(int ext[6], const int wholeExt[])
        Clamps ext to fit in wholeExt.
        """
        ret = self._wrap_call(self._vtk_obj.Clamp, *args)
        return ret

    def grow(self, *args):
        """
        grow(ext:[int, int, int, int, int, int], count:int) -> None
        C++: static void grow(int ext[6], int count)
        grow(ext:[int, int, int, int, int, int], count:int, wholeExt:[int,
             int, int, int, int, int]) -> None
        C++: static void grow(int ext[6], int count, int wholeExt[6])
        Grows the ext on each side by the given count.
        """
        ret = self._wrap_call(self._vtk_obj.Grow, *args)
        return ret

    def smaller(self, *args):
        """
        smaller(ext:(int, int, int, int, int, int), wholeExt:(int, int,
            int, int, int, int)) -> bool
        C++: static bool smaller(const int ext[6], const int wholeExt[6])
        Returns if ext fits within wholeExt. Unlike strictly_smaller, this
        method returns true even if ext == wholeExt.
        """
        ret = self._wrap_call(self._vtk_obj.Smaller, *args)
        return ret

    def strictly_smaller(self, *args):
        """
        strictly_smaller(ext:(int, int, int, int, int, int), wholeExt:(int,
             int, int, int, int, int)) -> bool
        C++: static bool strictly_smaller(const int ext[6],
            const int wholeExt[6])
        Returns true if ext is fits within wholeExt with at least 1
        dimension smaller than the wholeExt.
        """
        ret = self._wrap_call(self._vtk_obj.StrictlySmaller, *args)
        return ret

    def transform(self, *args):
        """
        transform(ext:[int, int, int, int, int, int], wholeExt:[int, int,
            int, int, int, int]) -> None
        C++: static void transform(int ext[6], int wholeExt[6])
        Makes ext relative to wholeExt.
        """
        ret = self._wrap_call(self._vtk_obj.Transform, *args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(StructuredExtent, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit StructuredExtent properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit StructuredExtent properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit StructuredExtent properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

