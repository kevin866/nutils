# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.locator import Locator


class AbstractCellLocator(Locator):
    r"""
    AbstractCellLocator - an abstract base class for locators which
    find cells
    
    Superclass: Locator
    
    AbstractCellLocator is a spatial search object to quickly locate
    cells in 3D. AbstractCellLocator supplies a basic interface which
    concrete subclasses should implement.
    
    @warning
    When deriving a class from AbstractCellLocator, one should include
    the 'hidden' member functions by the following construct in the
    derived class
      using AbstractCellLocator::IntersectWithLine;
      using AbstractCellLocator::FindClosestPoint;
      using AbstractCellLocator::FindClosestPointWithinRadius;
      using AbstractCellLocator::FindCell;
     
    
    @sa
    Locator CellLocator StaticCellLocator CellTreeLocator
    ModifiedBSPTree OBBTree
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkAbstractCellLocator, obj, update, **traits)
    
    cache_cell_bounds = tvtk_base.true_bool_trait(desc=\
        r"""
        Boolean controls whether the bounds of each cell are computed
        only once and then saved.  Should be 10 to 20% faster if
        repeatedly calling any of the Intersect/Find routines and the
        extra memory won't cause disk caching (48 extra bytes per cell
        are required to save the bounds).
        """
    )

    def _cache_cell_bounds_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetCacheCellBounds,
                        self.cache_cell_bounds_)

    lazy_evaluation = tvtk_base.false_bool_trait(desc=\
        r"""
        Most Locators build their search structures during build_locator
        but some may delay construction until it is actually needed. If
        lazy_evaluation is supported, this turns on/off the feature. if
        not supported, it is ignored.
        """
    )

    def _lazy_evaluation_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetLazyEvaluation,
                        self.lazy_evaluation_)

    retain_cell_lists = tvtk_base.true_bool_trait(desc=\
        r"""
        Boolean controls whether to maintain list of cells in each node.
        not applicable to all implementations, but if the locator is
        being used as a geometry simplification technique, there is no
        need to keep them.
        """
    )

    def _retain_cell_lists_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetRetainCellLists,
                        self.retain_cell_lists_)

    number_of_cells_per_node = traits.Trait(25, traits.Range(1, 2147483647, enter_set=True, auto_set=False), desc=\
        r"""
        Specify the preferred/maximum number of cells in each
        node/bucket. Default 32. Locators generally operate by
        subdividing space into smaller regions until the number of cells
        in each region (or node) reaches the desired level.
        """
    )

    def _number_of_cells_per_node_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfCellsPerNode,
                        self.number_of_cells_per_node)

    def compute_cell_bounds(self):
        """
        compute_cell_bounds(self) -> None
        C++: void compute_cell_bounds()
        This function can be used either internally or externally to
        compute only the cached cell bounds if cache_cell_bounds is on.
        """
        ret = self._vtk_obj.ComputeCellBounds()
        return ret
        

    def find_cell(self, *args):
        """
        find_cell(self, x:[float, float, float]) -> int
        C++: virtual IdType find_cell(double x[3])
        find_cell(self, x:[float, float, float], tol2:float,
            GenCell:GenericCell, pcoords:[float, float, float],
            weights:[float, ...]) -> int
        C++: virtual IdType find_cell(double x[3], double tol2,
            GenericCell *GenCell, double pcoords[3], double *weights)
        find_cell(self, x:[float, float, float], tol2:float,
            GenCell:GenericCell, subId:int, pcoords:[float, float,
            float], weights:[float, ...]) -> int
        C++: virtual IdType find_cell(double x[3], double tol2,
            GenericCell *GenCell, int &subId, double pcoords[3],
            double *weights)
        Returns the Id of the cell containing the point, returns -1 if no
        cell found. This interface uses a tolerance of zero
        
        THIS FUNCTION IS NOT THREAD SAFE.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FindCell, *my_args)
        return ret

    def find_cells_along_line(self, *args):
        """
        find_cells_along_line(self, p1:(float, float, float), p2:(float,
            float, float), tolerance:float, cells:IdList) -> None
        C++: virtual void find_cells_along_line(const double p1[3],
            const double p2[3], double tolerance, IdList *cells)
        Take the passed line segment and intersect it with the data set.
        For each intersection with the bounds of a cell, the cellIds have
        the relevant information added sort by t. If cellIds is nullptr
        pointer, then no information is generated for that list.
        
        A AbstractCellLocator subclass needs to implement
        intersect_with_line that takes cells ids, which is used internally
        to implement find_cells_along_line.
        
        THIS FUNCTION IS THREAD SAFE.
        """
        my_args = deref_array(args, [(('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'vtkIdList')])
        ret = self._wrap_call(self._vtk_obj.FindCellsAlongLine, *my_args)
        return ret

    def find_cells_along_plane(self, *args):
        """
        find_cells_along_plane(self, o:(float, float, float), n:(float,
            float, float), tolerance:float, cells:IdList) -> None
        C++: virtual void find_cells_along_plane(const double o[3],
            const double n[3], double tolerance, IdList *cells)
        Given an unbounded plane defined by an origin o[3] and unit
        normal n[3], return the list of unique cell ids in the buckets
        containing the plane. It is possible that an empty cell list is
        returned. The user must provide the IdList cell list to
        populate. This method returns data only after the locator has
        been built.
        
        THIS FUNCTION IS THREAD SAFE.
        """
        my_args = deref_array(args, [(('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'vtkIdList')])
        ret = self._wrap_call(self._vtk_obj.FindCellsAlongPlane, *my_args)
        return ret

    def find_cells_within_bounds(self, *args):
        """
        find_cells_within_bounds(self, bbox:[float, ...], cells:IdList)
            -> None
        C++: virtual void find_cells_within_bounds(double *bbox,
            IdList *cells)
        Return a list of unique cell ids inside of a given bounding box.
        The user must provide the IdList to populate.
        
        THIS FUNCTION IS THREAD SAFE.
        """
        my_args = deref_array(args, [('tuple', 'vtkIdList')])
        ret = self._wrap_call(self._vtk_obj.FindCellsWithinBounds, *my_args)
        return ret

    def find_closest_point(self, *args):
        """
        find_closest_point(self, x:(float, float, float),
            closestPoint:[float, float, float], cellId:int, subId:int,
            dist2:float) -> None
        C++: virtual void find_closest_point(const double x[3],
            double closestPoint[3], IdType &cellId, int &subId,
            double &dist2)
        find_closest_point(self, x:(float, float, float),
            closestPoint:[float, float, float], cell:GenericCell,
            cellId:int, subId:int, dist2:float) -> None
        C++: virtual void find_closest_point(const double x[3],
            double closestPoint[3], GenericCell *cell,
            IdType &cellId, int &subId, double &dist2)
        Return the closest point and the cell which is closest to the
        point x. The closest point is somewhere on a cell, it need not be
        one of the vertices of the cell.
        
        A AbstractCellLocator subclass needs to implement
        find_closest_point_within_radius which is used internally to
        implement find_closest_point.
        
        THIS FUNCTION IS NOT THREAD SAFE.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FindClosestPoint, *my_args)
        return ret

    def find_closest_point_within_radius(self, *args):
        """
        find_closest_point_within_radius(self, x:[float, float, float],
            radius:float, closestPoint:[float, float, float], cellId:int,
            subId:int, dist2:float) -> int
        C++: virtual IdType find_closest_point_within_radius(double x[3],
            double radius, double closestPoint[3], IdType &cellId,
            int &subId, double &dist2)
        find_closest_point_within_radius(self, x:[float, float, float],
            radius:float, closestPoint:[float, float, float],
            cell:GenericCell, cellId:int, subId:int, dist2:float)
            -> int
        C++: virtual IdType find_closest_point_within_radius(double x[3],
            double radius, double closestPoint[3], GenericCell *cell,
            IdType &cellId, int &subId, double &dist2)
        find_closest_point_within_radius(self, x:[float, float, float],
            radius:float, closestPoint:[float, float, float],
            cell:GenericCell, cellId:int, subId:int, dist2:float,
            inside:int) -> int
        C++: virtual IdType find_closest_point_within_radius(double x[3],
            double radius, double closestPoint[3], GenericCell *cell,
            IdType &cellId, int &subId, double &dist2, int &inside)
        Return the closest point within a specified radius and the cell
        which is closest to the point x. The closest point is somewhere
        on a cell, it need not be one of the vertices of the cell. This
        method returns 1 if a point is found within the specified radius.
        If there are no cells within the specified radius, the method
        returns 0 and the values of closestPoint, cellId, subId, and
        dist2 are undefined.
        
        THIS FUNCTION IS NOT THREAD SAFE.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.FindClosestPointWithinRadius, *my_args)
        return ret

    def inside_cell_bounds(self, *args):
        """
        inside_cell_bounds(self, x:[float, float, float], cell_ID:int)
            -> bool
        C++: virtual bool inside_cell_bounds(double x[3], IdType cell_ID)
        Quickly test if a point is inside the bounds of a particular
        cell. Some locators cache cell bounds and this function can make
        use of fast access to the data. This function should be used ONLY
        after the locator is built.
        """
        ret = self._wrap_call(self._vtk_obj.InsideCellBounds, *args)
        return ret

    def intersect_with_line(self, *args):
        """
        intersect_with_line(self, p1:(float, float, float), p2:(float,
            float, float), tol:float, t:float, x:[float, float, float],
            pcoords:[float, float, float], subId:int) -> int
        C++: virtual int intersect_with_line(const double p1[3],
            const double p2[3], double tol, double &t, double x[3],
            double pcoords[3], int &subId)
        intersect_with_line(self, p1:(float, float, float), p2:(float,
            float, float), tol:float, t:float, x:[float, float, float],
            pcoords:[float, float, float], subId:int, cellId:int) -> int
        C++: virtual int intersect_with_line(const double p1[3],
            const double p2[3], double tol, double &t, double x[3],
            double pcoords[3], int &subId, IdType &cellId)
        intersect_with_line(self, p1:(float, float, float), p2:(float,
            float, float), tol:float, t:float, x:[float, float, float],
            pcoords:[float, float, float], subId:int, cellId:int,
            cell:GenericCell) -> int
        C++: virtual int intersect_with_line(const double p1[3],
            const double p2[3], double tol, double &t, double x[3],
            double pcoords[3], int &subId, IdType &cellId,
            GenericCell *cell)
        intersect_with_line(self, p1:(float, float, float), p2:(float,
            float, float), points:Points, cellIds:IdList) -> int
        C++: virtual int intersect_with_line(const double p1[3],
            const double p2[3], Points *points, IdList *cellIds)
        intersect_with_line(self, p1:(float, float, float), p2:(float,
            float, float), tol:float, points:Points, cellIds:IdList)
             -> int
        C++: virtual int intersect_with_line(const double p1[3],
            const double p2[3], const double tol, Points *points,
            IdList *cellIds)
        intersect_with_line(self, p1:(float, float, float), p2:(float,
            float, float), tol:float, points:Points, cellIds:IdList,
             cell:GenericCell) -> int
        C++: virtual int intersect_with_line(const double p1[3],
            const double p2[3], const double tol, Points *points,
            IdList *cellIds, GenericCell *cell)
        Return intersection point (if any) of finit ...
         [Truncated]
        """
        my_args = deref_array(args, [(('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'float', ['float', 'float', 'float'], ['float', 'float', 'float'], 'int'), (('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'float', ['float', 'float', 'float'], ['float', 'float', 'float'], 'int', 'int'), (('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'float', ['float', 'float', 'float'], ['float', 'float', 'float'], 'int', 'int', 'vtkGenericCell'), (('float', 'float', 'float'), ('float', 'float', 'float'), 'vtkPoints', 'vtkIdList'), (('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'vtkPoints', 'vtkIdList'), (('float', 'float', 'float'), ('float', 'float', 'float'), 'float', 'vtkPoints', 'vtkIdList', 'vtkGenericCell')])
        ret = self._wrap_call(self._vtk_obj.IntersectWithLine, *my_args)
        return ret

    def shallow_copy(self, *args):
        """
        shallow_copy(self, __a:AbstractCellLocator) -> None
        C++: virtual void shallow_copy(AbstractCellLocator *)
        Shallow copy of a AbstractCellLocator.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.ShallowCopy, *my_args)
        return ret

    _updateable_traits_ = \
    (('cache_cell_bounds', 'GetCacheCellBounds'), ('lazy_evaluation',
    'GetLazyEvaluation'), ('retain_cell_lists', 'GetRetainCellLists'),
    ('automatic', 'GetAutomatic'), ('use_existing_search_structure',
    'GetUseExistingSearchStructure'), ('debug', 'GetDebug'),
    ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('number_of_cells_per_node', 'GetNumberOfCellsPerNode'), ('max_level',
    'GetMaxLevel'), ('tolerance', 'GetTolerance'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['automatic', 'cache_cell_bounds', 'debug', 'global_warning_display',
    'lazy_evaluation', 'retain_cell_lists',
    'use_existing_search_structure', 'max_level',
    'number_of_cells_per_node', 'object_name', 'tolerance'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(AbstractCellLocator, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit AbstractCellLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['automatic', 'cache_cell_bounds', 'lazy_evaluation',
            'retain_cell_lists', 'use_existing_search_structure'], [],
            ['max_level', 'number_of_cells_per_node', 'object_name',
            'tolerance']),
            title='Edit AbstractCellLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit AbstractCellLocator properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

