# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class FieldData(Object):
    r"""
    FieldData - represent and manipulate fields of data
    
    Superclass: Object
    
    FieldData represents and manipulates fields of data. The model of
    a field is a m x n matrix of data values, where m is the number of
    tuples, and n is the number of components. (A tuple is a row of n
    components in the matrix.) The field is assumed to be composed of a
    set of one or more data arrays, where the data in the arrays are of
    different types (e.g., int, double, char, etc.), and there may be
    variable numbers of components in each array. Note that each data
    array is assumed to be "m" in length (i.e., number of tuples), which
    typically corresponds to the number of points or cells in a dataset.
    Also, each data array must have a character-string name. (This is
    used to manipulate data.)
    
    There are two ways of manipulating and interfacing to fields. You can
    do it generically by manipulating components/tuples via a double-type
    data exchange, or you can do it by grabbing the arrays and
    manipulating them directly. The former is simpler but performs type
    conversion, which is bad if your data has non-castable types like
    (void) pointers, or you lose information as a result of the cast.
    The, more efficient method means managing each array in the field. 
    Using this method you can create faster, more efficient algorithms
    that do not lose information.
    
    @sa
    AbstractArray DataSetAttributes PointData CellData
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkFieldData, obj, update, **traits)
    
    ghosts_to_skip = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        
        """
    )

    def _ghosts_to_skip_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetGhostsToSkip,
                        self.ghosts_to_skip)

    number_of_tuples = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        Set the number of tuples for each data array in the field. This
        method should not be used if the instance is from a subclass of
        FieldData (vtkpoint_data or CellData). This is because in
        those cases, the attribute data is stored with the other fields
        and will cause the method to behave in an unexpected way.
        """
    )

    def _number_of_tuples_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetNumberOfTuples,
                        self.number_of_tuples)

    def get_abstract_array(self, *args):
        """
        get_abstract_array(self, i:int) -> AbstractArray
        C++: AbstractArray *get_abstract_array(int i)
        get_abstract_array(self, arrayName:str, index:int)
            -> AbstractArray
        C++: AbstractArray *get_abstract_array(const char *arrayName,
            int &index)
        get_abstract_array(self, arrayName:str) -> AbstractArray
        C++: AbstractArray *get_abstract_array(const char *arrayName)
        Returns the ith array in the field. Unlike get_array(), this
        method returns a AbstractArray and can be used to access any
        array type. A nullptr is returned only if the index i is out of
        range.
        """
        ret = self._wrap_call(self._vtk_obj.GetAbstractArray, *args)
        return wrap_vtk(ret)

    def _get_actual_memory_size(self):
        return self._vtk_obj.GetActualMemorySize()
    actual_memory_size = traits.Property(_get_actual_memory_size, desc=\
        r"""
        Return the memory in kibibytes (1024 bytes) consumed by this
        field data. Used to support streaming and reading/writing data.
        The value returned is guaranteed to be greater than or equal to
        the memory required to actually represent the data represented by
        this object.
        """
    )

    def get_array(self, *args):
        """
        get_array(self, i:int) -> DataArray
        C++: DataArray *get_array(int i)
        get_array(self, arrayName:str, index:int) -> DataArray
        C++: DataArray *get_array(const char *arrayName, int &index)
        get_array(self, arrayName:str) -> DataArray
        C++: DataArray *get_array(const char *arrayName)
        Not recommended for use. Use get_abstract_array(int i) instead.
        
        Return the ith array in the field. A nullptr is returned if the
        index i is out of range, or if the array at the given index is
        not a DataArray. To access StringArray, or VariantArray,
        use get_abstract_array(int i).
        """
        ret = self._wrap_call(self._vtk_obj.GetArray, *args)
        return wrap_vtk(ret)

    def get_array_containing_component(self, *args):
        """
        get_array_containing_component(self, i:int, arrayComp:int) -> int
        C++: int get_array_containing_component(int i, int &arrayComp)
        Return the array containing the ith component of the field. The
        return value is an integer number n 0<=n<this->number_of_arrays.
        Also, an integer value is returned indicating the component in
        the array is returned. Method returns -1 if specified component
        is not in the field.
        """
        ret = self._wrap_call(self._vtk_obj.GetArrayContainingComponent, *args)
        return ret

    def get_array_name(self, *args):
        """
        get_array_name(self, i:int) -> str
        C++: const char *get_array_name(int i)
        Get the name of ith array. Note that this is equivalent to:
        get_abstract_array(i)->get_name() if ith array pointer is not
        nullptr
        """
        ret = self._wrap_call(self._vtk_obj.GetArrayName, *args)
        return ret

    def get_field(self, *args):
        """
        get_field(self, ptId:IdList, f:FieldData) -> None
        C++: void get_field(IdList *ptId, FieldData *f)
        Get a field from a list of ids. Supplied field f should have same
        types and number of data arrays as this one (i.e., like
        copy_structure() creates).  This method should not be used if the
        instance is from a subclass of FieldData (vtkpoint_data or
        CellData).  This is because in those cases, the attribute data
        is stored with the other fields and will cause the method to
        behave in an unexpected way.
        """
        my_args = deref_array(args, [('vtkIdList', 'vtkFieldData')])
        ret = self._wrap_call(self._vtk_obj.GetField, *my_args)
        return ret

    def get_finite_range(self, *args):
        """
        get_finite_range(self, name:str, range:[float, float], comp:int=0)
            -> bool
        C++: bool get_finite_range(const char *name, double range[2],
            int comp=0)
        get_finite_range(self, index:int, range:[float, float], comp:int=0)
            -> bool
        C++: bool get_finite_range(int index, double range[2], int comp=0)"""
        ret = self._wrap_call(self._vtk_obj.GetFiniteRange, *args)
        return ret

    def _get_ghost_array(self):
        return wrap_vtk(self._vtk_obj.GetGhostArray())
    ghost_array = traits.Property(_get_ghost_array, desc=\
        r"""
        Get the ghost array, if present in this field data. If no ghost
        array is set, returns `nullptr`. A ghost array is a
        `vtkunsigned_char_array` called `vtkghost_type`. See
        `vtkdata_set_attributes` for more context on ghost types.
        
        @sa
        DataSetAttributes
        """
    )

    def _get_number_of_arrays(self):
        return self._vtk_obj.GetNumberOfArrays()
    number_of_arrays = traits.Property(_get_number_of_arrays, desc=\
        r"""
        Get the number of arrays of data available. This does not include
        nullptr array pointers therefore after fd->allocate_array(n);
        nArrays = get_number_of_arrays() nArrays is not necessarily equal to
        n.
        """
    )

    def _get_number_of_components(self):
        return self._vtk_obj.GetNumberOfComponents()
    number_of_components = traits.Property(_get_number_of_components, desc=\
        r"""
        Get the number of components in the field. This is determined by
        adding up the components in each non-nullptr array. This method
        should not be used if the instance is from a subclass of
        FieldData (vtkpoint_data or CellData). This is because in
        those cases, the attribute data is stored with the other fields
        and will cause the method to behave in an unexpected way.
        """
    )

    def get_range(self, *args):
        """
        get_range(self, name:str, range:[float, float], comp:int=0) -> bool
        C++: bool get_range(const char *name, double range[2], int comp=0)
        get_range(self, index:int, range:[float, float], comp:int=0)
            -> bool
        C++: bool get_range(int index, double range[2], int comp=0)
        Computes the range of the input data array (specified through its
        `name` or the `index` in this field data). If the targeted array
        is not polymorphic with a `vtkdata_array`, or if no array match
        the input `name` or `index`, or if `comp` is out of bounds, then
        the returned range is `[NaN, NaN]`.
        
        The computed range is cached to avoid recomputing it. The range
        is recomputed if the held array has been modified, if
        `ghosts_to_skip` has been changed, or if the ghost array has been
        changed / modified.
        
        If a ghost array is present in the field data, then the binary
        mask `ghosts_to_skip` is used to skip values associated with a
        ghost that intersects this mask.
        
        `comp` targets which component of the array the range is to be
        computed on. Setting it to -1 results in computing the range of
        the magnitude of the array.
        
        The `Finite` version of this method skips infinite values in the
        array in addition to ghosts matching with `ghosts_to_skip`.
        """
        ret = self._wrap_call(self._vtk_obj.GetRange, *args)
        return ret

    def add_array(self, *args):
        """
        add_array(self, array:AbstractArray) -> int
        C++: int add_array(AbstractArray *array)
        Add an array to the array list. If an array with the same name
        already exists - then the added array will replace it. Return the
        index of the added array.
        """
        my_args = deref_array(args, [['vtkAbstractArray']])
        ret = self._wrap_call(self._vtk_obj.AddArray, *my_args)
        return ret

    def allocate(self, *args):
        """
        allocate(self, sz:int, ext:int=1000) -> int
        C++: TypeBool allocate(IdType sz, IdType ext=1000)
        Allocate data for each array. Note that ext is no longer used.
        """
        ret = self._wrap_call(self._vtk_obj.Allocate, *args)
        return ret

    def allocate_arrays(self, *args):
        """
        allocate_arrays(self, num:int) -> None
        C++: void allocate_arrays(int num)
        allocate_of_arrays actually sets the number of AbstractArray
        pointers in the FieldData object, not the number of used
        pointers (arrays). Adding more arrays will cause the object to
        dynamically adjust the number of pointers if it needs to extend.
        Although allocate_arrays can be used if the number of arrays which
        will be added is known, it can be omitted with a small
        computation cost.
        """
        ret = self._wrap_call(self._vtk_obj.AllocateArrays, *args)
        return ret

    def copy_all_off(self, *args):
        """
        copy_all_off(self, unused:int=0) -> None
        C++: virtual void copy_all_off(int unused=0)
        Turn off copying of all data. During the copying/passing, the
        following rules are followed for each array:
        1. If the copy flag for an array is set (on or off), it is
           applied This overrides rule 2.
        2. If copy_all_on is set, copy the array. If copy_all_off is set, do
           not copy the array
        """
        ret = self._wrap_call(self._vtk_obj.CopyAllOff, *args)
        return ret

    def copy_all_on(self, *args):
        """
        copy_all_on(self, unused:int=0) -> None
        C++: virtual void copy_all_on(int unused=0)
        Turn on copying of all data. During the copying/passing, the
        following rules are followed for each array:
        1. If the copy flag for an array is set (on or off), it is
           applied This overrides rule 2.
        2. If copy_all_on is set, copy the array. If copy_all_off is set, do
           not copy the array
        """
        ret = self._wrap_call(self._vtk_obj.CopyAllOn, *args)
        return ret

    def copy_field_off(self, *args):
        """
        copy_field_off(self, name:str) -> None
        C++: void copy_field_off(const char *name)"""
        ret = self._wrap_call(self._vtk_obj.CopyFieldOff, *args)
        return ret

    def copy_field_on(self, *args):
        """
        copy_field_on(self, name:str) -> None
        C++: void copy_field_on(const char *name)
        Turn on/off the copying of the field specified by name. During
        the copying/passing, the following rules are followed for each
        array:
        1. If the copy flag for an array is set (on or off), it is
           applied This overrides rule 2.
        2. If copy_all_on is set, copy the array. If copy_all_off is set, do
           not copy the array
        """
        ret = self._wrap_call(self._vtk_obj.CopyFieldOn, *args)
        return ret

    def copy_structure(self, *args):
        """
        copy_structure(self, __a:FieldData) -> None
        C++: void copy_structure(FieldData *)
        Copy data array structure from a given field.  The same arrays
        will exist with the same types, but will contain nothing in the
        copy.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.CopyStructure, *my_args)
        return ret

    def deep_copy(self, *args):
        """
        deep_copy(self, da:FieldData) -> None
        C++: virtual void deep_copy(FieldData *da)
        Copy a field by creating new data arrays (i.e., duplicate
        storage).
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.DeepCopy, *my_args)
        return ret

    def extended_new(self):
        """
        extended_new() -> FieldData
        C++: static FieldData *extended_new()"""
        ret = wrap_vtk(self._vtk_obj.ExtendedNew())
        return ret
        

    def has_array(self, *args):
        """
        has_array(self, name:str) -> int
        C++: int has_array(const char *name)
        Return 1 if an array with the given name could be found. 0
        otherwise.
        """
        ret = self._wrap_call(self._vtk_obj.HasArray, *args)
        return ret

    def initialize(self):
        """
        initialize(self) -> None
        C++: virtual void initialize()
        Release all data but do not delete object. Also, clear the copy
        flags.
        """
        ret = self._vtk_obj.Initialize()
        return ret
        

    def insert_next_tuple(self, *args):
        """
        insert_next_tuple(self, j:int, source:FieldData) -> int
        C++: IdType insert_next_tuple(const IdType j,
            FieldData *source)
        Insert the jth tuple in source field data at the end of the tuple
        matrix. Range checking is performed and memory is allocated as
        necessary.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.InsertNextTuple, *my_args)
        return ret

    def insert_tuple(self, *args):
        """
        insert_tuple(self, i:int, j:int, source:FieldData) -> None
        C++: void insert_tuple(const IdType i, const IdType j,
            FieldData *source)
        Insert the jth tuple in source field data at the ith location.
        Range checking is performed and memory allocates as necessary.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.InsertTuple, *my_args)
        return ret

    def null_data(self, *args):
        """
        null_data(self, id:int) -> None
        C++: void null_data(IdType id)
        Sets every DataArray at index id to a null tuple.
        """
        ret = self._wrap_call(self._vtk_obj.NullData, *args)
        return ret

    def pass_data(self, *args):
        """
        pass_data(self, fd:FieldData) -> None
        C++: virtual void pass_data(FieldData *fd)
        Pass entire arrays of input data through to output. Obey the
        "copy" flags.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.PassData, *my_args)
        return ret

    def remove_array(self, *args):
        """
        remove_array(self, name:str) -> None
        C++: virtual void remove_array(const char *name)
        remove_array(self, index:int) -> None
        C++: virtual void remove_array(int index)
        Remove an array (with the given name or index) from the list of
        arrays.
        """
        ret = self._wrap_call(self._vtk_obj.RemoveArray, *args)
        return ret

    def reset(self):
        """
        reset(self) -> None
        C++: void reset()
        Resets each data array in the field (Reset() does not release
        memory but it makes the arrays look like they are empty.)
        """
        ret = self._vtk_obj.Reset()
        return ret
        

    def set_tuple(self, *args):
        """
        set_tuple(self, i:int, j:int, source:FieldData) -> None
        C++: void set_tuple(const IdType i, const IdType j,
            FieldData *source)
        Set the jth tuple in source field data at the ith location. Set
        operations mean that no range checking is performed, so they're
        faster.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.SetTuple, *my_args)
        return ret

    def shallow_copy(self, *args):
        """
        shallow_copy(self, da:FieldData) -> None
        C++: virtual void shallow_copy(FieldData *da)
        Copy a field by reference counting the data arrays.
        """
        my_args = [deref_vtk(x) for x in args]
        ret = self._wrap_call(self._vtk_obj.ShallowCopy, *my_args)
        return ret

    def squeeze(self):
        """
        squeeze(self) -> None
        C++: void squeeze()
        Squeezes each data array in the field (Squeeze() reclaims unused
        memory.)
        """
        ret = self._vtk_obj.Squeeze()
        return ret
        

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('ghosts_to_skip', 'GetGhostsToSkip'),
    ('number_of_tuples', 'GetNumberOfTuples'), ('object_name',
    'GetObjectName'), ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'ghosts_to_skip',
    'number_of_tuples', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(FieldData, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit FieldData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['ghosts_to_skip', 'number_of_tuples', 'object_name']),
            title='Edit FieldData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit FieldData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

