# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.data_object import DataObject


class AbstractElectronicData(DataObject):
    r"""
    AbstractElectronicData - Provides access to and storage of
    chemical electronic data
    
    Superclass: DataObject
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkAbstractElectronicData, obj, update, **traits)
    
    def _get_electron_density(self):
        return wrap_vtk(self._vtk_obj.GetElectronDensity())
    electron_density = traits.Property(_get_electron_density, desc=\
        r"""
        Returns ImageData for the molecule's electron density. The
        data will be calculated when first requested, and cached for
        later requests.
        """
    )

    def _get_homo(self):
        return wrap_vtk(self._vtk_obj.GetHOMO())
    homo = traits.Property(_get_homo, desc=\
        r"""
        Returns ImageData for the Highest Occupied Molecular Orbital.
        """
    )

    def _get_homo_orbital_number(self):
        return self._vtk_obj.GetHOMOOrbitalNumber()
    homo_orbital_number = traits.Property(_get_homo_orbital_number, desc=\
        r"""
        Returns the orbital number of the Highest Occupied Molecular
        Orbital.
        """
    )

    def _get_lumo(self):
        return wrap_vtk(self._vtk_obj.GetLUMO())
    lumo = traits.Property(_get_lumo, desc=\
        r"""
        Returns ImageData for the Lowest Unoccupied Molecular Orbital.
        """
    )

    def _get_lumo_orbital_number(self):
        return self._vtk_obj.GetLUMOOrbitalNumber()
    lumo_orbital_number = traits.Property(_get_lumo_orbital_number, desc=\
        r"""
        Returns the orbital number of the Lowest Unoccupied Molecular
        Orbital.
        """
    )

    def get_mo(self, *args):
        """
        get_mo(self, orbitalNumber:int) -> ImageData
        C++: virtual ImageData *get_mo(IdType orbitalNumber)
        Returns the ImageData for the requested molecular orbital.
        """
        ret = self._wrap_call(self._vtk_obj.GetMO, *args)
        return wrap_vtk(ret)

    def _get_number_of_electrons(self):
        return self._vtk_obj.GetNumberOfElectrons()
    number_of_electrons = traits.Property(_get_number_of_electrons, desc=\
        r"""
        Returns the number of electrons in the molecule.
        """
    )

    def _get_number_of_m_os(self):
        return self._vtk_obj.GetNumberOfMOs()
    number_of_m_os = traits.Property(_get_number_of_m_os, desc=\
        r"""
        Returns the number of molecular orbitals available.
        """
    )

    def _get_padding(self):
        return self._vtk_obj.GetPadding()
    padding = traits.Property(_get_padding, desc=\
        r"""
        Get the padding between the molecule and the cube boundaries.
        This is used to determine the dataset's bounds.
        """
    )

    def is_homo(self, *args):
        """
        is_homo(self, orbitalNumber:int) -> bool
        C++: bool is_homo(IdType orbitalNumber)
        Returns true if the given orbital number is the Highest Occupied
        Molecular Orbital, false otherwise.
        """
        ret = self._wrap_call(self._vtk_obj.IsHOMO, *args)
        return ret

    def is_lumo(self, *args):
        """
        is_lumo(self, orbitalNumber:int) -> bool
        C++: bool is_lumo(IdType orbitalNumber)
        Returns true if the given orbital number is the Lowest Unoccupied
        Molecular Orbital, false otherwise.
        """
        ret = self._wrap_call(self._vtk_obj.IsLUMO, *args)
        return ret

    _updateable_traits_ = \
    (('global_release_data_flag', 'GetGlobalReleaseDataFlag'), ('debug',
    'GetDebug'), ('global_warning_display', 'GetGlobalWarningDisplay'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_release_data_flag', 'global_warning_display',
    'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(AbstractElectronicData, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit AbstractElectronicData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View((['global_release_data_flag'], [], ['object_name']),
            title='Edit AbstractElectronicData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit AbstractElectronicData properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

