# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class StereoCompositor(Object):
    r"""
    StereoCompositor - helper class to generate composited stereo
    images.
    
    Superclass: Object
    
    StereoCompositor is used by RenderWindow to composite left and
    right eye rendering results into a single color buffer.
    
    Note that all methods on StereoCompositor take in pointers to the
    left and right rendering results and generate the result in the
    buffer passed for the left eye.
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkStereoCompositor, obj, update, **traits)
    
    def anaglyph(self, *args):
        """
        anaglyph(self, rgbLeftNResult:UnsignedCharArray,
            rgbRight:UnsignedCharArray, colorSaturation:float,
            colorMask:(int, int)) -> bool
        C++: bool anaglyph(UnsignedCharArray *rgbLeftNResult,
            UnsignedCharArray *rgbRight, float colorSaturation,
            const int colorMask[2])"""
        my_args = deref_array(args, [('vtkUnsignedCharArray', 'vtkUnsignedCharArray', 'float', ('int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.Anaglyph, *my_args)
        return ret

    def checkerboard(self, *args):
        """
        checkerboard(self, rgbLeftNResult:UnsignedCharArray,
            rgbRight:UnsignedCharArray, size:(int, int)) -> bool
        C++: bool checkerboard(UnsignedCharArray *rgbLeftNResult,
            UnsignedCharArray *rgbRight, const int size[2])"""
        my_args = deref_array(args, [('vtkUnsignedCharArray', 'vtkUnsignedCharArray', ('int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.Checkerboard, *my_args)
        return ret

    def dresden(self, *args):
        """
        dresden(self, rgbLeftNResult:UnsignedCharArray,
            rgbRight:UnsignedCharArray, size:(int, int)) -> bool
        C++: bool dresden(UnsignedCharArray *rgbLeftNResult,
            UnsignedCharArray *rgbRight, const int size[2])"""
        my_args = deref_array(args, [('vtkUnsignedCharArray', 'vtkUnsignedCharArray', ('int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.Dresden, *my_args)
        return ret

    def interlaced(self, *args):
        """
        interlaced(self, rgbLeftNResult:UnsignedCharArray,
            rgbRight:UnsignedCharArray, size:(int, int)) -> bool
        C++: bool interlaced(UnsignedCharArray *rgbLeftNResult,
            UnsignedCharArray *rgbRight, const int size[2])"""
        my_args = deref_array(args, [('vtkUnsignedCharArray', 'vtkUnsignedCharArray', ('int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.Interlaced, *my_args)
        return ret

    def red_blue(self, *args):
        """
        red_blue(self, rgbLeftNResult:UnsignedCharArray,
            rgbRight:UnsignedCharArray) -> bool
        C++: bool red_blue(UnsignedCharArray *rgbLeftNResult,
            UnsignedCharArray *rgbRight)
        Methods for compositing left and right eye images based on
        various supported modes. See RenderWindow::SetStereoType for
        explanation of each of these modes. Note that all these methods
        generate the result in the buffer passed for the left eye.
        """
        my_args = deref_array(args, [('vtkUnsignedCharArray', 'vtkUnsignedCharArray')])
        ret = self._wrap_call(self._vtk_obj.RedBlue, *my_args)
        return ret

    def split_viewport_horizontal(self, *args):
        """
        split_viewport_horizontal(self, rgbLeftNResult:UnsignedCharArray,
             rgbRight:UnsignedCharArray, size:(int, int)) -> bool
        C++: bool split_viewport_horizontal(
            UnsignedCharArray *rgbLeftNResult,
            UnsignedCharArray *rgbRight, const int size[2])"""
        my_args = deref_array(args, [('vtkUnsignedCharArray', 'vtkUnsignedCharArray', ('int', 'int'))])
        ret = self._wrap_call(self._vtk_obj.SplitViewportHorizontal, *my_args)
        return ret

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('object_name', 'GetObjectName'),
    ('reference_count', 'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(StereoCompositor, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit StereoCompositor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name']),
            title='Edit StereoCompositor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit StereoCompositor properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

