# Automatically generated code: EDIT AT YOUR OWN RISK
from traits import api as traits
from traitsui.item import Item, spring
from traitsui.group import HGroup
from traitsui.view import View

from tvtk import vtk_module as vtk
from tvtk import tvtk_base
from tvtk.tvtk_base_handler import TVTKBaseHandler
from tvtk import messenger
from tvtk.tvtk_base import deref_vtk
from tvtk import array_handler
from tvtk.array_handler import deref_array
from tvtk.tvtk_classes.tvtk_helper import wrap_vtk

nan = float('nan')


def InstanceEditor(*args, **kw):
    from traitsui.editors.api import InstanceEditor as Editor
    return Editor(view_name="handler.view")

try:
    long
except NameError:
    # Silly workaround for Python3.
    long = int

inf = float('inf')

from tvtk.tvtk_classes.object import Object


class GraphicsFactory(Object):
    r"""
    GraphicsFactory - 
    
    Superclass: Object
    
    """
    def __init__(self, obj=None, update=True, **traits):
        tvtk_base.TVTKBase.__init__(self, vtk.vtkGraphicsFactory, obj, update, **traits)
    
    off_screen_only_mode = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        This option enables the off-screen only mode. In this mode no X
        calls will be made even when interactor is used.
        """
    )

    def _off_screen_only_mode_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetOffScreenOnlyMode,
                        self.off_screen_only_mode)

    use_mesa_classes = traits.Int(0, enter_set=True, auto_set=False, desc=\
        r"""
        This option enables the creation of Mesa classes instead of the
        open_gl classes when using mangled Mesa.
        """
    )

    def _use_mesa_classes_changed(self, old_val, new_val):
        self._do_change(self._vtk_obj.SetUseMesaClasses,
                        self.use_mesa_classes)

    def _get_render_library(self):
        return self._vtk_obj.GetRenderLibrary()
    render_library = traits.Property(_get_render_library, desc=\
        r"""
        What rendering library has the user requested
        """
    )

    def create_instance(self, *args):
        """
        create_instance(vtkclassname:str) -> Object
        C++: static Object *create_instance(const char *vtkclassname)
        Create and return an instance of the named vtk object. This
        method first checks the ObjectFactory to support dynamic
        loading.
        """
        ret = self._wrap_call(self._vtk_obj.CreateInstance, *args)
        return wrap_vtk(ret)

    _updateable_traits_ = \
    (('debug', 'GetDebug'), ('global_warning_display',
    'GetGlobalWarningDisplay'), ('off_screen_only_mode',
    'GetOffScreenOnlyMode'), ('use_mesa_classes', 'GetUseMesaClasses'),
    ('object_name', 'GetObjectName'), ('reference_count',
    'GetReferenceCount'))
    
    _allow_update_failure_ = \
    ()
    
    _full_traitnames_list_ = \
    (['debug', 'global_warning_display', 'object_name',
    'off_screen_only_mode', 'use_mesa_classes'])
    
    def trait_view(self, name=None, view_element=None):
        if view_element is not None or name not in (None, '', 'traits_view', 'full_traits_view', 'view'):
            return super(GraphicsFactory, self).trait_view(name, view_element)
        if name == 'full_traits_view':
            full_traits_view = \
            View((Item("handler._full_traits_list",show_label=False)),
            title='Edit GraphicsFactory properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return full_traits_view
        elif name == 'view':
            view = \
            View(([], [], ['object_name', 'off_screen_only_mode',
            'use_mesa_classes']),
            title='Edit GraphicsFactory properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return view
        elif name in (None, 'traits_view'):
            traits_view = \
            View((HGroup(spring, "handler.view_type", show_border=True), 
            Item("handler.info.object", editor = InstanceEditor(view_name="handler.view"), style = "custom", show_label=False)),
            title='Edit GraphicsFactory properties', scrollable=True, resizable=True,
            handler=TVTKBaseHandler,
            buttons=['OK', 'Cancel'])
            return traits_view
            

